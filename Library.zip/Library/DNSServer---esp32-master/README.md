# DNSServer
ESP8266/ESP32 DNSServer library

This is an experimental port of the DNSServer library that should work on
ESP8266 and ESP32. This is NOT an official repo supported by Espressif. Do not
depend on this code for anything important or expect it to be updated. Once the
official repo is created, this repo will be deleted.
